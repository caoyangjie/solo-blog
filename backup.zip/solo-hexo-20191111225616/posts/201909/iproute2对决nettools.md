title: iproute2 对决 net-tools
date: '2019-09-15 20:13:47'
updated: '2019-09-15 20:13:47'
tags: [Docker, linux, 高级路由技巧]
permalink: /articles/2019/09/15/1568549627291.html
---
1. 什么是高级路由？
是把信息从源穿过网络到达目的地的行为. 有两个动作：确定最佳路径，传输信息
确定最佳路径：手工指定，自动学习。
 传输信息：隧道传输，流量整形
高级路由（策略路由）是根据一定的需要定下一些策略为依据。
rpdb(routing policy data base)通过一定的规则进行路由
 
2.什么是多路由表及规则？
 （1） 多路由表用来等待匹配，默认有四张路由表 
 255 是本地路由表 
 254 主路由表 没有指明表所属位置 都放在这里
 253 默认路由表 
 0 系统保留的表
（2）规则
 rpdb可以匹配数据包的源地址 目的地址 进入接口
 每一个路由
 动作 选择下一跳地址， 产生通讯时被
 
3.ip
 ip link show 显示所有的网络设备
 ip address show 
 ip route show table 255 显示指定编号的表
 ip rule 定义规则
 ip rule add from 192.168.2.1／32 table 1 从192.168.2.1的包按照1的表进行匹配
 ip rule show 显示规则 
 ip rule add from 192.168.2.1／24 pref 1000 prohibit 从192.168.2.1的包返回不可达
 ip rule del pref 32764 删除规则
 ip route add 192.168.2.0／24 via 202.96.156.111 table 1 访问外网
例如 
 ip rule add 192.168.2.1 table 1 pref 1000
 ip rule add 192.168.2.2 table 1 pref 1005
 ip rule add 192.168.2.3 table 1 pref 1010
 ip rule add 192.168.2.0/24 table 2 pref 1015
 ip route add 192.168.2.0/24 via 2M table 1
 ip route add 192.168.2.0/24 via 1M table 2
 
 ip route add default via 192.168.1.1 table 2 proto statc 设置默认网关 （ip route flush cache 刷新表1的缓存）
 ip route flush table 1 清空表
负载均衡
 1M 2M
 ip route add default scope global nexthop via ip1 dev eth0 weight 1 nexthop via ip2 dev eth1 weight 1
 第一跳eth0 第二跳eth1 第三跳 eth0 。。。。。。。。 
 ip route add default scope global nexthop via ip1 dev eth0 weight 2 nexthop via ip2 dev eth1 weight 1
 第一跳eth0分2／3 第二条eth1 1／3
 实验
 有三种人老板 美眉 我 员工

4.IP 隧道 （ip-ip）
 一层 ip－ip
 二层 GRE
 三层 ipsec ｛加密（ESP），认证（AH），协商（IKE）｝
 隧道模式 主机包头－－AH－－ESP－－数据
 传输模式 安全网关头部－－AH－－ESP－－主机头｜数据 （VPN） 
 NtoN 虚拟处于一个局域网中


解释
1.qdisc 队列
2.pfifo_fast (先进先出)有3个频道
 priomap:
3.（1）令牌桶过滤器 （tbf）
 数据流＝令牌流 无延迟的通过队列
 数据流<令牌流 消耗一部分令牌 剩下的在桶里积累，直到桶被填满，剩下的会在令牌>数据的时候消耗掉
 数据流>令牌流 导致tbf中断一断时间 发生丢包现象
 （2）使用
 limit/latency 最多有多少数据在队列中等待可用的令牌／确定了一个包在tbf中等待传输的最长等待时间
 burst／buffer／maxburst 桶的大小 （字节） 10M bit/s的速率－－－10k字节
 mpu 令牌的最低消耗 （0长度的包需要消耗64字节的带宽）
 rate 速度操纵
4.实验
 tc qdisc add dev eth0 root tbf rate 220kbit latency 50ms burst 1540
 将网卡设备eth0加入队列中，以root为根的令牌桶，数据不超过220k速率通过，当数据包等待50ms没有拿到令牌 则丢弃，定义桶的大小为1540字节
5.随机公平队列 （sfq）
 解释：将流量分为相当多的FIFO队列中 每个队列对应一个会话数据按照简单轮转方式发送，每个会话都按顺序得到发送机会
 解决问题：网络阻塞
 参数：1.perturb 多少秒重新配置一次散列算法，一般为10m
 2.quantum 一个流要传输多少字节后才切换到下个队列 一般设为一个包的最大长度
6.tc qdisc add dev ppp0 root sfq perturb 10
7.队列的选取
 降低出口速率 令牌桶过滤器
 链路已经塞满，想保证不会有某一个会话独占出口带宽， 使用随机公平队列
 有一个很大的骨干带宽， 随机丢包
 希望对入口流量整形 入口流量整形
8.分类的队列规定 cbq
 



实验
 要求：总体的网络布局，有三种人 学生 教师 教职员工，
1.学生：每栋宿舍分10m带宽 需要流量整形，学生不和教职员工的网络连接，不可以访问外部网络，可以访问学校内部的FTP 和视频点播服务器
2.教师：共享10m带宽，教师的网络和教职员工的网络连通 可以访问学校的FTP 视频点播 web服务器
3.教职员工：共享1 0m带宽，可以访问学校内部的web服务器 不能访问FTP 和视频点播
服务器：web服务器用来提供erp 有一个站点 用来提供资料下载，ftp服务器 保存各种视频资料，视频课件 ，视频点播服务器：提供教师学生视频 娱乐 外部的web服务器。学校的主站 学校内部有四个网络机房，平时上课用来做实验 晚上用来上网，四个机房共享100m带宽。网络安全，外部不能访问内部的视频 ftp服务器。注意防止改变ip地址获得其他角色的服务。希望有一套机制监控全校的网络使用状况

~new~ppp的包
rp-pppoe-3.5-32.1
ppp-2.4.4-1.el5
/etc/ppp/pppoe-server-options (options)
验证方式
pap pap-secrets（不可用）
chap chap-secrets
 man pppd
vim pppoe-server-options
# PPP options for the PPPoE server
# LIC: GPL
require-chap
login
lcp-echo-interval 10
lcp-echo-failure 2
ms-dns 192.168.0.22 给客户端
logfile /var/log/pppoe.log

vim chap-secrets
# Secrets for authentication using CHAP
# client server secret IP addresses
####### redhat-config-network will overwrite this part!!! (begin) ##########
joker * 123456 *
tom * 123456 *
jerry * 123456 *
shrek * 123456 *
####### redhat-config-network will overwrite this part!!! (end) ############

uname -r rhel5 u1 u2 
service syslog stop 有bug,u3没有bug
pppoe-service -I eth0 -L 172.16.0.1 -R 10.0.0.1 -N 100
 服务器地址 客户端地址池
客户端adsl-setup
adsl-start
adsl-stop


tc 流量控制 sfq tbf

CLASSFUL QDISCS
HTB 分层令牌桶
PRIO tc class ls dev eth0
tc qd add dev eth0 root prio
tc qd add dev eth0 parent 8016:1 tbf rate 10kbit limit 5k burst 5k
tc qd add dev eth0 parent 8016:2 sfq
tc qd add dev eth0 parent 8016:3 sfq


 tc qd ls
qdisc pfifo_fast 0: dev eth1 bands 3 priomap 1 2 2 2 1 2 0 0 1 1 1 1 1 1 1 1

tc qd add dev eth0 root sfq
tc qd del dev eth0 root sfq
tc qd add dev eth0 root pfifo
tc qd add dev eth0 root tbf rate 256kbit limit 10k burst 10k
tc qd add dev eth0 root handle 1: tbf rate 256kbit limit 10k burst 10k
1:0 1:2 ......
高级路由
pppoe点到点协议
利用pppoe可防止arp欺骗
adsl-setup这是拨号上网的命令
radius的记帐服务器 AAA协议
安装包：
rpm -ivh pp-2.4.4....
 rp-pppoe-3.5-32.1
cd /etc/ppp
vim pppoe-servar
身份验证方式：
chap-secrets
pap-secrets不能用
修改
---------
require-chap
login
lcp-echo-interval 10密码身份验证
lcp-echo-railure 2
以下为添加：
ms-dns 192.168.0.254此处为dns地址
logfile /var/log/pppo.log日志路径
-----------------
man pppd
查看可添加的配置参数
－－－－－－－－－－－－－－－－－
创建帐户和密码
vim chap-secrets
zorro * 123456（密码明文） *(可分配的ip，要在地址段内）
－－－－－－－－－－－－－－－－
查版本：
uname -r
rhel5 u1 u2之间是冲突的
service syslog stop 关闭日志：这是必需的
-------------------
设置网卡监听
pppoe-server -I eht0 -L(指定虚ip.登录后可见到的ip）172.16.0.1－R（分给客户端的ip）10.0.0.1－N 100(个数是100个）
－－－－－－－－－－－－－－－－－－－－－－
客户端拨号
adsl-setup
1eth0(哪个网卡连接的就用哪个网卡建）
2name：aorro
3网卡：eth0
4dns：
5passwd:
6是否允许一般用户启动：
7防火墙规则：0
9是否保存设置：
－－－－－－－－－
启动拨号：
adsl-start
中断拨号：
adsl-stop
-------------
客户间通信是要通过服务器的＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊
－－－－－－－－－－－－－－－－－－－
查看日志：
tail -f /var/log/pppoe.log
记录登录目录
服务器设置的用户名才能能真正登录的
－－－－－－－－－－－－－－－－－－－－－－－
设置记帐：
时间记帐：的对话叫：aaloth-up；实际的ip连接：ip-up;退出过程：aloth-down;(这个时间是记帐的最好时间）
数据包量查看：（流量记帐）
netstat -i
－－－－－－－－－－－－
为记帐建立脚本：
vim /auth-up
#!/bin/bash
export LANG=C

echo $PEERNAME login at 'date' >> /tmp/pppd-login.log这是帐户登录的时间
－－－－－
vim /auth-down
#!/bin/bash
LANG=C
echo $PEERNAME logout in 'date' >> /tmp/pppd-loging.log这是帐户登出的时间
---------
kilkall -9
cat /tmp/pppd-login.log
-----------
怎样限制客户端的速度：客户端下行速度，在服务器端限制是上行速度。
tc命令：
网卡：
tc
ssh 10.0.0.93
服务器端限制上行速度：
tc qdisc add dev ppp1 root tbf rate 256kbit limit 10k burst 10k 这是对ppp1的上行速度做的限制
重启服务：
service httpd restart
去掉限速：add＞＞del
-------------
自动设置限速：
vim /etc/ppp/ip-up
[ -x /etc/ppp/ip-up.local ] && /etc/ppp/ip-up.local "$@"下面加入：
设置vip同帐户
if [ $PEERNAME = " zorro"]
then
 tc qdisc add dev $IFNAME root tbf rate 512kbit limit 10k burst 10k
 exit 0
fi
tc qdisc add dev $IFNAME root tbf rate 512kbit limit 10k burst 10k

查看：
tc qdisc list
kailkill -9 pppd

ip ad sh************************
－－－－－－－－－－－－－－－－－－－－－－－－－－－
tc交通控制：
OBJECT:1 qdisc:队列规则；队列的优先级依次排列，前面比后面的高［0.1.2共计16个，不同的位标记为不同的队列：一般服务排在中间队列。］。
2class：
3filter：
4action：
5monitor：
tc qd 显示当前所有队列规则：
qdisc pfifo_fast 0: dev eth0 bands 3 priomap 1 2 2 2 1 2 0 0 1 1 1 1 1 1 1 1
0000：1 0001：20010：2 0011：2这个队列规则为pfifo_fast
man tc 
两大类：
不可分类;CLASSLESS QDISCS
1 [p|b]fifo
2 pfifo_fast
3 red随机优先
4 sfq完全公平
5 tbf没有所谓的队列，相当只有一个队列，令牌总队列。
每一个会话连接称为：session 完全公平
默认是tc qd 
tc qd add dev eth0 root sfq修改默认队列规则
tcqd del dev etho root sfq 删除队列规则
tc qd add dev eth0 root pfifo添加规则
tc qd add dev eth0 root tbf rate 256kbit （limit 10 ＜burst 10令牌总的参数＞） 附属参数［添加规则时必须加参数，不然会报错］
8015：此外为编号，可指定加
tc qd add dev eth0 root handle 1: (不加数字，默认为0）tbf rate 256kbit limit 10 burst 10
网卡上行限速 tbf
－－－－－－－－－－－－－－
分分类队列规则：
CBQ：在高端应用广，软件上做即时限速是不准确的。软件上不适用。
HTB：分层令牌总
PRIO:
tc qd add dev eth0 root prio区别是分类了
tc class ls dev eth0 查验，默认产生3个类，还是以tos值分。8016：1、2、3，各有不同的优先级，类下可再加队列规则：要指定具体父类
tc qd add dev eth0 parent 8016:1 tbf rate 10kbit limit 5k burst 5k
tc qd add dev eth0 parent 8016:2 sfq 
tc qd add dev eth0 parent 8016:3 sfq
－－－－－－－－－－－－－－－－
人为方式指定，而不是tos值。
tc qd del dev etho root
tc qd add dev eth0 root handle 1:prio
tc cl ls dev eth0查看
tc qd add dev eth0 parent 1:1 tbf rate 256kbit burst 200k(字节）limit 10k 
tc qd add dev eth0 parent 1:2 tbf rate 5mbit burst 3m limit 10k
tc qd add dev eth0 parent 1:3 tbf rate 1mbit burst 1mlimit 10k
tc qd add dev eth0 parent 1:protocol ip prio 1001 (优先级）u32(过滤器类型） match ip(报头）dst 192.168.0.120 flowid 1:1
tc qd add dev eth0 parent 1:protocol ip prio 1001 (优先级）u32(过滤器类型） match ip(报头）dst 192.168.0.128 flowid 1:2
tc qd add dev eth0 parent 1:protocol ip prio 1001 (优先级）u32(过滤器类型） match ip(报头）dst 192.168.0.0／24 flowid 1:3其他人共享1m带宽｛这就是分组处理｝这是ip限制。
环境：
10m带宽，scp ssh smtp http 规定流量:scp10k；http5m，无其他人时10m；smtp5m
man tc8
pro实现
-------------
history 
删除数字：
：1，＄s/^ .... *\(tc.*$)/\1/g
-----------
脚本1
vim 
#!/bin/bash



wget http://192.168.0.254:/var/ftp/ki....

＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿
建立文件：
dd it=/dev/zer of=/varftp/bigfile
＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿
tc qd ls






查看路径：
man pppd
在SCRIPTS中可看到相应的参数提示


#双线路由切换

rpm -q iproute iproute-2.6.18-4.el5
ip address show dev eth0
ip ad sh dev eth1

[root@localhost ~]# ip
Usage: ip [ OPTIONS ] OBJECT { COMMAND | help }
 ip [ -force ] [-batch filename
where OBJECT := { link | addr | route | rule | neigh | ntable | tunnel |
 maddr | mroute | monitor | xfrm }
 OPTIONS := { -V[ersion] | -s[tatistics] | -r[esolve] |
 -f[amily] { inet | inet6 | ipx | dnet | link } |
 -o[neline] | -t[imestamp] }
ip link ,ip li sh,ip li help,
[root@localhost ~]# ip ad add dev eth1 192.168.5.3/24
[root@localhost ~]# ip ad sh dev eth1
[root@localhost ~]# ip ad del dev eth1 192.168.5.3/24
[root@localhost ~]# ip ne sh //看arp，
[root@localhost ~]# ip ne help
Usage: ip neigh { add | del | change | replace } { ADDR [ lladdr LLADDR ]
 [ nud { permanent | noarp | stale | reachable } ]
 | proxy ADDR } [ dev DEV ]
 ip neigh {show|flush} [ to PREFIX ] [ dev DEV ] [ nud STATE ]
[root@localhost ~]# ip route sh ,ip ro sh
ip ro add 10.0.0.1/32 dev eth1 ,route add -host 10.0.0.1 dev eth1
ip ro del 10.0.0.1/32 dev eth1
ip ro sh
ip ro add default dev eth0 via 192.168.0.1
ss -antp
*ip ro del default
ip ro default dev nexthop dev eth0 via 211.0.0.1 weight 10 nexthop dev eth1 via 123.112.0.1 weight 5
ip ro sh

如果通过服务器上网，服务器做的是默认路由。
vim root
#!/bin/bash
IFNAME1＝eth0
IFNAME2=ETH1
IP1=211.0.01
IP2=123.112.0.1

while :
do
 route del default
 route add default dev $IFNAME1 gw $IP1
 
 while ping -c 1 211.0.0.1 & /dev/null
 do 
 sleep 1
 done
 
 route del default
 route add default dev $IFNAME2 gw $IP2
 
 until ping -c 1 211.0.0.1 & /dev/null
 do
 sleep 1
 done
done
这是互备的内容
----------------------------
改变需求：两条线同时上网，
默认路由是支持一条路由的，不能同时支持二条
cd /usr/src/linux-2.6..
make menuconfig
IP：equal cost multipath选中
－－－－－－－－－－－－－－－－－－以上为填加高级路由必须操作的
 rpm -q iproute 这是支持高级路由的包
ifconfig
route -n 
netstat 
ip address show dev eth0显示eth0的网卡地址
ip ad sh dev eth0同上命令，这是简写命令
-------一定要查看以上命令
ip 回车是命令参数
ip link只针对三层
ip ad 所有网卡显示
ip ad add dev eth0 192.168.1.254/24这是填加ip
ip ad sh dev etho这是立即生效的ipconfig是看不见的
ip ad del dev eth0 192.168.0.254/24这是删除
编辑ip ad sh dev eth0
显示链路层ip li 
ip li help帮助
--------------------
查看arp协议ip ne sh
相当于：arp －n
ip ne help帮助
ip rout sh 查看路由
ip ro sh同上
ip ro add 10.0.0.1/32 dev eth1添加路由 发往ip的包由eth1发出
route add -host 10.0.0.1 dev eth1
ip ro del 10.0.0.1/32 dev eth1
ip ro add 100.0.0/8 dev eth0
ip ro sh 
ip ro del 10.0.0.0/8 dev eth0
ip ro del default
ip ro add default dev eth0 via 192.168.0.1
ip ro sh
ss -antp
ip ro add default dev eth0 via 192.168.0.1
-----------
添加ecmp
ip ro del default
ip ro add default dev eth0 via 211.0.0.1这是加一个
加二个，后面加：
ip ro add default nexthop dev eth0 via 211.0.0.1 nexthop dev eth1 via 123.112.0.1注意参数
加权重：
ip ro add default nexthop dev eth0 via 211.0.0.1 weight 10 nexthop dev eth1 via 123.112.0.1 weight5
ip ro add default nexthop dev eth0 via 192.168.0.1 weight 10 nexthop dev eth1 via 192.168.1.2 weight 5
ip ro sh 这是查看
－－－－－－－－－－－－
ecmp支持的问题
脚本：
vim ar_ecmp.sh
#!/bin/bash

IFNAME=eth0
IPNAME=eth1
IFNAME=eth2
#........
#IFNAME=ethn

IP1＝192.168.1.1
IP2＝192.168.1.2
IP3＝192.168.1.3
#.......
#IPn=xxx.xxx.xxx.xxx

ip ro del default
ip ro add default nexthop dev $IFNAME1 via $IP1 seight 1 \
 nexthop dev $IFNAME2 via $IP2 seight 1 \
 nexthop dev $IFNAME3 via $IP3 seight 1 #\
# .......
-------------以上为ecmp
高级路由：
部分上网走10m，部分走1m
ip ro sh table local这是所有经过本机的路由表
ip ro sh table all 这是本机所有的路由表
策略表：rule表，指定如何查其他表，匹配规则，这是路由的策略机制。可在策略这查ip经过的路由表
可在策略表中指定ip范围所经过的带宽
ip ro sh显示当前；默认路由
cd /etc/
vim rt_tables
#reserved values
255 local
254 main
253 unspec
111 ta2
101 ta1 添加时要按顺序
#
#local 
ip ro sh ta 254
ip ro sh ta ta1
ip ro sh ta ta2
以上两表添加相应的路由
ip ro add 192.168.0.0/24 dev eth1 ta ta1
ip ro add 192.168.1.0/24 dev eth1 ta ta1
ip ro sh ta ta1
ip ro del 192.168.0.0/24 dev eth1 ta ta1
ip ro add 192.168.0.0/24 dev eth0 ta ta1
ip ro sh ta ta1
ip ro add default dev eth0 via 192.168.0.1 ta ta1
ip ro sh ta ta1
ip ro add 192.168.0.0/24 dev eth0 ta ta2
ip ro add 192.168.1.0/24 dev eth1 ta ta2
ip ro add default dev eth1 via 192.168.1.1 ta ta2
ip ro sh ta ta2
ip ro sh ta ta1
设置策略，如何查表
ip rule show
[root@www ~]# ip rule show
0: from all lookup 255 
32766: from all lookup main 
32767: from all lookup default 
You have new mail in /var/spool/mail/root
顺序从上至下查表
加规则：不同网段查不同表1～100查1表，101～253查2表
ip ru(route) help帮助
ip ru add from 192.168.0.1 ta ta1
for i in 'seq 2 100';do ip ru add from 192.168.0.$i ta t1;done
for i in 'seq 2 253';do ip ru add from 192.168.0.$i ta t2;done
ip ru show
删除：
for in in 'seq 1 253';do ip rou del from 192.168.0.$i;done
ip ru sh
_____________更换查找方式
防火墙和高级路由联用：
iptables -t mangle -A PREROUTING -m iprange --src-range 192.168.0.1-192.168.0.100 -j MARK --set-mark 1
iptables -t mangle -A PREROUTING -m iprange --src-range 192.168.0.101-192.168.0.253 -j MARK --set-mark 2
ip ru help
ip ru add fwmark 1 ta ta1
ip ru add rwmark 2 ta ta2
ip ru sh 
-----------
TC联用
－－－－－－－－－
这是不同原地址发的带宽不一样
－－－－－－－－－－－－－－－
定义默认规则：
ip ro sh 默认def表：
ip ro sh 
ip ro sh ta ta1
vim /etc/iproute2/rt_
ip ro sh ta ta1
ip ru sh
ip ru del fwmark 2
ip ru del fwmark 1
ip ru sh 
ip ru add to 211.0.0.1 ta ta1
ip ru sh
根据目标地址指定以上
防火墙添加标记
ip ru help
---------------
要掌握结构
ab测试
ab -c 100 -n 1000 http://192.168.0.254
vmstat 1
renice -20 ?
ps ax |grep httpd
ps ax |grep /usr/sbin/bttp |sed "$d' |awk ‘｛print $1}';do renice -20 $i;done
for i in 'ps ax|grep /usr/sbin/httpd |sed '
************************************
vim 
#!/bin/bash

count=""
ret=0

for ((count=1000;count<=3000;count++))
do
 for ((i=2;i<count;i++)
 do 
 if ［ $[$count%$i] = 0]
 then
 rte=0
 break
 fi
 ret=1
 confinue
 done
 if [ $ret = 1 ]
 then
 echo $count
 fi
done




http://wdicc.com/linux-bridge-script/


Linux下双网接入高级路由配置脚本zz
http://lwfs.net/2005/11/28/10/
    #!/bin/bash

    IP0=
    IP1=
    GW0=
    GW1=
    NET0=
    NET1=
    DEV0=eth0
    DEV1=eth1

    # comment the next two line after first run this script.
    echo 200 cernet >>/etc/iproute2/rt_tables
    echo 210 chinanet >>/etc/iproute2/rt_tables

    ip route add ${NET0} dev ${DEV0} src ${IP0} table cernet
    ip route add default via ${GW0} table cernet
    ip route add ${NET1} dev ${DEV1} src ${IP1} table chinanet
    ip route add default via ${GW1} table chinanet
    ip route add ${NET0} dev ${DEV0} src ${IP0}
    ip route add ${NET1} dev ${DEV1} src ${IP1}

    # delete old rule
    ip rule del from ${IP0}
    ip rule del from ${IP1}
    # setup new rule
    ip rule add from ${IP0} table cernet
    ip rule add from ${IP1} table chinanet 



http://jpuyy.com/2014/01/ip-rule-and-ip-route.html
ip rule和 ip route
发表于2014 年 1 月 13 日
相对ip route ，ip rule是高级路由，能实现不同条件路由的转发。
linux系统维护了路由表，用ip rule show可以查看路由表。
# ip rule show
0: from all lookup local 
32766: from all lookup main 
32767: from all lookup default
路由表记录在/etc/iproute2/rt_tables文件中，默认里面会用这么几行，在这个文件里添加的路由表即时生效
255 local
254 main
253 default
0 unspec
所以自定义一个路由表的时候，序号要在1-252之间，路由选择的优先级也与数字的大小有关，越小的优先级越高，先匹配。
数字后面要规定一个别名，方便使用和辨认。
这样路由表的查看可有以下两种方法：
ip route list table table_number
ip route list table table_name
如查看默认路由表可用如下命令
ip route list table main
ip route list table 254
路由表添加完之后，接下来就是对路由表的操作，如果我有
eth1 配置ip 192.168.1.8/24 路由表 101 mytable1
eth2 配置ip  192.168.2.8/24 路由表 102 mytable2
不同段的从不同的网卡走。
ip route add 192.168.1.0 dev eth1 src 192.168.1.8 table mytable1
ip route add default via 192.168.1.1 table mytable1
ip rule add from 192.168.1.8 table mytable1

ip route add 192.168.2.0 dev eth2 src 192.168.2.8 table mytable2
ip route add default via 192.168.2.1 table mytable2
ip rule add from 192.168.2.8 table mytable2
现在使用ip rule show查看
# ip rule show
 0: from all lookup local
 32764: from 192.168.2.8 lookup mytable2
 32765: from 192.168.1.8 lookup mytable1
 32766: from all lookup main
 32767: from all lookup default
这时要删除rule可使用
ip rule del prio 32764
ip rule还可以实现更高级的功能，比如根据ip目的地址，包大小来进行转发。
查看route -n flag
The flags
Following is the list of flags and their significance in the routing table :
U : This flag signifies that the route is up
G : This flag signifies that the route is to a gateway. If this flag is not present then we can say that the route is to a directly connected destination
H : This flag signifies that the route is to a host which means that the destination is a complete host address. If this flag is not present then it can be assumed that the route is to a network and destination would be a network address.
D : This flag signifies that this route is created by a redirect.
M : This flag signifies that this route is modified by a redirect.
 
 
http://blog.csdn.net/bytxl/article/details/9850803
策略路由以及使用 ip route ， ip rule ， iptables 配置策略路由实例
分类： 网络 linux 命令2013-08-09 10:36 560人阅读 评论(0) 收藏 举报
 
目录(?)[+]
 
http://blog.sina.com.cn/s/blog_659b48590100n2q6.html
例：
 
公司内网要求192.168.0.100以内的使用 10.0.0.1 网关上网（电信），其他IP使用 20.0.0.1 （网通）上网。
 
首先要在网关服务器上添加一个默认路由，当然这个指向是绝大多数的IP的出口网关。
 
# ip route add default gw 20.0.0.1
 
之后通过 ip route 添加一个路由表
 
# ip route add table 3 via 10.0.0.1 dev ethX
 (ethX是10.0.0.1所在的网卡，3 是路由表的编号)
 
之后添加 ip  rule 规则
 
# ip rule add fwmark 3  table 3 
（fwmark 3是标记，table 3 是路由表3 上边。 意思就是凡是标记了 3 的数据使用table3 路由表）
 
之后使用iptables给相应的数据打上标记：
 
# iptables -A PREROUTING -t mangle -i eth0 -s 192.168.0.1 -192.168.0.100 -j MARK --set-mark 3
 
因为mangle的处理是优先于 nat 和fiter表的，所以相应数据包到达之后先打上标记，之后再通过ip rule规则。对应的数据包使用相应的路由表进行路由，最后读取路由表信息，将数据包送出网关。
 
-------------------------------------------------------------------------------------------------------------------------------------
 
ip rule 命令
linux 高级路由即基于策略的路由，比传统路由在功能上更强大，使用也更灵活，它不仅能够像传统路由一样，根据目的地址来转发数据，而且也能够根据报文大小、应用，协议或ip源地址来选择路由转发路径从而让系统管理员能轻松做到：
1、 管制某台计算机的带宽。
2、 管制通向某台计算机的带宽
3、 帮助你公平地共享带宽
4、 保护你的网络不受DOS的攻击
5、 保护你的Internet不受到你的客户的攻击
6、 把多台服务器虚拟成一台，并进行负载均衡或者提高可用性
7、 限制你的用户访问某些计算机
8、 限制对你的计算机的访问
9、 基于用户帐号、MAC地址、源IP地址、端口、QOS《TOS》、时间或者content等进行路由
 
一、高级路由的基础IP ROUTE2
基本命令：
ip link list 显示ip链路状态信息
ip address show 除显示所有网络地址
ip route show 显示主路由表信息
ip neigh show 显示邻居表
linux系统路由表
linux可以自定义从1－252个路由表，
linux系统维护了4个路由表：
0表 系统保留表
 
255  local 本地路由表，存有本地接口地址，广播地址，以及NAT地址。
     local表由系统自动维护，管理员不能操作此表。
254  main 主路由表，传统路由表,ip route若没指定表即操作表254。
     注:平时用route查看的亦是此表设置的路由。
253  default  默认路由表一般存放默认路由。
     注：rt_tables文件中表以数字来区分表，保留最多支持255张表。

路由表的查看可有以下二种方法：
      ip route list table table_number
      ip route list table table_name

路由表序号和表名的对应关系在/etc/iproute2/rt_tables中，可手动编辑。
路由表添加完毕即时生效，下面为实例：
# ip route add default via 192.168.1.1 table 1                       在1表中添加默认路由为192.168.1.1
# ip route add 192.168.0.0/24 via 192.168.1.2                     添加一条到192.168.0.0网段的路由为192.168.1.2
注:各路由表中应当指明默认路由，尽量不回查路由表。路由添加完毕，即可在路由规则中应用。
高级路由重点之一路由规则 ip rule
进行路由时，根据路由规则来进行匹配，按优先级（pref）从低到高匹配，直到找到合适的规则，所以在应用中配置默认路由是必要的。
ip rule show 显示路由规则。
路由规则的添加：
# ip rule add from 192.168.1.10/32 table 1 pref 100
如果pref值不指定，则将在已有规则最小序号前插入
注：创建完路由规则若需立即生效须执行
#ip route flush cache
刷新路由缓冲。
 
命令格式如下：
        Usage: ip rule [ list | add | del ] SELECTOR ACTION
        SELECTOR := [ from PREFIX ] [ to PREFIX ] [ tos TOS ][ dev STRING ] [ pref NUMBER ]
        ACTION := [ table TABLE_ID ] [ nat ADDRESS ][ prohibit | reject | unreachable ]
                  [ flowid CLASSID ]
        TABLE_ID := [ local | main | default | new | NUMBER ]

    参数解析如下：
        From -- 源地址
        To -- 目的地址（这里是选择规则时使用，查找路由表时也使用）
　　Tos -- IP包头的TOS（type of sevice）域Linux高级路由-
　　Dev -- 物理接口
　    Fwmark -- iptables标签
    采取的动作除了指定路由表外，还可以指定下面的动作：
        Table 指明所使用的表
  　   Nat 透明网关
　　 Prohibit 丢弃该包，并发送 COMM.ADM.PROHIITED的ICMP信息 
　　 Reject 单纯丢弃该包
　　 Unreachable丢弃该包， 并发送 NET UNREACHABLE的ICMP信息
 
    路由表添加完毕,即可在策略路由表内添加路由。
例:
      #ip route add 192.168.1.0/24 dev eth0 via 192.168.1.66 realm 4
        注:发往子网192.168.1.0/24的数据包通过分类4转发配合tc使用,后文有介绍讲解...
      #ip route add default via 192.168.1.1 table int1
      #ip route add 192.168.1.0/24 via 192.168.1.1 table int2
      #ip route add 172.16.0.2/16 via 172.16.0.1 table int3
        注:各路由表中应当指明默认路由,尽量不回查路由表.路由添加完毕,即可在路由规则中应用。
    #ip rule sh 显示路由规则 
      0:      from all lookup local 
      32766:  from all lookup main 
      32767:  from all lookup default 
    进行路由时，正是根据路由规则来进行匹配，按优先级(pref后数值)从高到低匹配,直到找到合适的规则.所以在应用中配置默认路由是必要的。
    策略路由一般手工添加路由表，路由表的添加只需编辑rt_tables文件，规定表序号，表名即可。
    ip rule规则添加示例： 
      #ip rule add from 192.168.1.112/32 [tos 0x10] table test2 pref 999 prohibit 
      #ip rule add to 192.168.1.2 pref 1000 table test1 
      #ip rule add from 192.168.1.0/24 pref 1001 table test1 
      #ip rule add [from 0/0] table test1 pref 1003 
      #ip rule add fwmark 1 pref 1002 table test2  
（此句型配合iptables -t mangle应用。如先对数据包作标记:
      #iptables -t mangle -A PREROUTING -p tcp -m multiport --dports 80,8080,20,21 -s 192.168.1.0/24 -j MARK --set-mark 1  ）
 
  Linux高级路由需结合iptables才能充分体现其功能的强大,实际工作中的应用多半基于此,当然要熟练掌握Linux高级路由+iptables 还需进一步的加强学习和实践的应用。
 
route 命令
使用 Route 命令行工具查看并编辑计算机的 IP 路由表。Route 命令和语法如下所示：
route [-f] [-p] [Command [Destination] [mask Netmask] [Gateway] [metric Metric]] [if Interface]]
-f 清除所有网关入口的路由表。  
-p 与 add 命令一起使用时使路由具有永久性。 
Command 指定您想运行的命令 (Add/Change/Delete/Print)。 
Destination 指定该路由的网络目标。  
mask Netmask 指定与网络目标相关的网络掩码（也被称作子网掩码）。  
Gateway 指定网络目标定义的地址集和子网掩码可以到达的前进或下一跃点 IP 地址。  
metric Metric 为路由指定一个整数成本值标（从 1 至 ArrayArrayArrayArray），当在路由表(与转发的数据包目标地址最匹配)的多个路由中进行选择时可以使用。  
if Interface 为可以访问目标的接口指定接口索引。若要获得一个接口列表和它们相应的接口索引，使用 route print 命令的显示功能。可以使用十进制或十六进制值进行接口索引。 
/?  在命令提示符处显示帮助。  
示例:
使用route 命令添加的路由，机器重启或者网卡重启后路由就失效了，方法：

　　//添加到主机的路由

　　# route add –host 192.168.168.110 dev eth0

　　# route add –host 192.168.168.119 gw 192.168.168.1

　　//添加到网络的路由

　　# route add –net IP netmask MASK eth0

　　# route add –net IP netmask MASK gw IP

　　# route add –net IP/24 eth1

　　//添加默认网关

　　# route add default gw IP

　　//删除路由

　　# route del –host 192.168.168.110 dev eth0
添加一条路由(发往192.168.62这个网段的全部要经过网关192.168.1.1：
　　route add -net 192.168.62.0 netmask 255.255.255.0 gw 192.168.1.1

　　删除一条路由
　　route del -net 192.168.122.0 netmask 255.255.255.0
　　删除的时候不用写网关。

若要显示 IP 路由表的全部内容，请键入：
# route print
Kernel IP routing table

　　Destination Gateway Genmask Flags Metric Ref Use Iface

　　10.147.9.0 * 255.255.255.0 U 1 0 0 eth0

　　192.168.1.0 * 255.255.255.0 U 2 0 0 wlan0

　　192.168.122.0 * 255.255.255.0 U 0 0 0 virbr0

　　link-local * 255.255.0.0 U 1000 0 0 eth0

　　192.168.0.0 192.168.1.1 255.255.0.0 UG 0 0 0 wlan0

　　default 10.147.9.1 0.0.0.0 UG 0 0 0 eth0

　　root@Ubuntu:~#

　　结果是自上而下， 就是说， 哪条在前面， 哪条就有优先， 前面都没有， 就用最后一条default。

若要显示以 10. 起始的 IP 路由表中的路由，请键入：
route print 10.*
若要添加带有 1Array2.168.12.1 默认网关地址的默认路由，请键入：
route add 0.0.0.0 mask 0.0.0.0 1Array2.168.12.1
若要向带有 255.255.0.0 子网掩码和 10.27.0.1 下一跃点地址的 10.41.0.0 目标中添加一个路由，请键入：
route add 10.41.0.0 mask 255.255.0.0 10.27.0.1
若要向带有 255.255.0.0 子网掩码和 10.27.0.1 下一跃点地址的 10.41.0.0 目标中添加一个永久路由，请键入：
route -p add 10.41.0.0 mask 255.255.0.0 10.27.0.1
若要向带有 255.255.0.0 子网掩码、10.27.0.1 下一跃点地址且其成本值标为 7 的 10.41.0.0 目标中添加一个路由，请键入：
route add 10.41.0.0 mask 255.255.0.0 10.27.0.1 metric 7
若要向带有 255.255.0.0 子网掩码、10.27.0.1 下一跃点地址且使用 0x3 接口索引的 10.41.0.0 目标中添加一个路由，请键入：
route add 10.41.0.0 mask 255.255.0.0 10.27.0.1 if 0x3
若要删除到带有 255.255.0.0 子网掩码的 10.41.0.0 目标的路由，请键入：
route delete 10.41.0.0 mask 255.255.0.0
若要删除以 10. 起始的 IP 路由表中的所有路由，请键入：
route delete 10.*
若要将带有 10.41.0.0 目标和 255.255.0.0 子网掩码的下一跃点地址从 10.27.0.1 修改为 10.27.0.25，请键入：
route change 10.41.0.0 mask 255.255.0.0 10.27.0.25

ip命令的语法
　　ip命令的用法如下：
　　ip [OPTIONS] OBJECT [COMMAND [ARGUMENTS]]
　　4.1 ip link set--改变设备的属性. 缩写：set、s
　　示例1：up/down 起动／关闭设备。
　　# ip link set dev eth0 up
　　这个等于传统的 # ifconfig eth0 up(down)
　　示例2：改变设备传输队列的长度。
　　参数:txqueuelen NUMBER或者txqlen NUMBER
　　# ip link set dev eth0 txqueuelen 100
　　示例3：改变网络设备MTU(最大传输单元)的值。
　　# ip link set dev eth0 mtu 1500
　　示例4： 修改网络设备的MAC地址。
　　参数: address LLADDRESS
　　# ip link set dev eth0 address 00:01:4f:00:15:f1
　　4.2 ip link show--显示设备属性. 缩写：show、list、lst、sh、ls、l
　　-s选项出现两次或者更多次，ip会输出更为详细的错误信息统计。
　　示例:
　　# ip -s -s link ls eth0
　　eth0: mtu 1500 qdisc cbq qlen 100
　　link/ether 00:a0:cc:66:18:78 brd ff:ff:ff:ff:ff:ff
　　RX: bytes packets errors dropped overrun mcast
　　2449949362 2786187 0 0 0 0
　　RX errors: length crc fifo missed
　　0 0 0 0 0
　　TX: bytes packets errors dropped carrier collsns
　　178558497 1783946 332 0 332 35172
　　TX errors: aborted fifo window heartbeat
　　0 0 0 332
　　这个命令等于传统的 ifconfig eth0
　　5.1 ip address add--添加一个新的协议地址. 缩写：add、a
　　示例1：为每个地址设置一个字符串作为标签。为了和Linux-2.0的网络别名兼容，这个字符串必须以设备名开头，接着一个冒号，
　　# ip addr add local 192.168.4.1/28 brd + label eth0:1 dev eth0
　　示例2: 在以太网接口eth0上增加一个地址192.168.20.0，掩码长度为24位(155.155.155.0)，标准广播地址，标签为eth0:Alias：
　　# ip addr add 192.168.4.2/24 brd + dev eth1 label eth1:1
　　这个命令等于传统的: ifconfig eth1:1 192.168.4.2
　　5.2 ip address delete--删除一个协议地址. 缩写：delete、del、d
　　# ip addr del 192.168.4.1/24 brd + dev eth0 label eth0:Alias1
　　5.3 ip address show--显示协议地址. 缩写：show、list、lst、sh、ls、l
　　# ip addr ls eth0
　　5.4.ip address flush--清除协议地址. 缩写：flush、f
　　示例1 : 删除属于私网10.0.0.0/8的所有地址：
　　# ip -s -s a f to 10/8
　　示例2 : 取消所有以太网卡的IP地址
　　# ip -4 addr flush label "eth0"
　　6. ip neighbour--neighbour/arp表管理命令
　　缩写 neighbour、neighbor、neigh、n
　　命令 add、change、replace、delete、fulsh、show(或者list)
　　6.1 ip neighbour add -- 添加一个新的邻接条目
　　ip neighbour change--修改一个现有的条目
　　ip neighbour replace--替换一个已有的条目
　　缩写：add、a；change、chg；replace、repl
　　示例1: 在设备eth0上，为地址10.0.0.3添加一个permanent ARP条目：
　　# ip neigh add 10.0.0.3 lladdr 0:0:0:0:0:1 dev eth0 nud perm
　　示例2:把状态改为reachable
　　# ip neigh chg 10.0.0.3 dev eth0 nud reachable
　　6.2.ip neighbour delete--删除一个邻接条目
　　示例1:删除设备eth0上的一个ARP条目10.0.0.3
　　# ip neigh del 10.0.0.3 dev eth0
　　6.3.ip neighbour show--显示网络邻居的信息. 缩写：show、list、sh、ls
　　示例1: # ip -s n ls 193.233.7.254
　　193.233.7.254. dev eth0 lladdr 00:00:0c:76:3f:85 ref 5 used 12/13/20 nud reachable
　　6.4.ip neighbour flush--清除邻接条目. 缩写：flush、f
　　示例1: (-s 可以显示详细信息)
　　# ip -s -s n f 193.233.7.254
　　7. 路由表管理
　　7.1.缩写 route、ro、r
　　7.2.路由表
　　从Linux-2.2开始，内核把路由归纳到许多路由表中，这些表都进行了编号，编号数字的范围是1到255。另外，
　　为了方便，还可以在/etc/iproute2/rt_tables中为路由表命名。
　　默认情况下，所有的路由都会被插入到表main(编号254)中。在进行路由查询时，内核只使用路由表main。
　　7.3.ip route add -- 添加新路由
　　ip route change -- 修改路由
　　ip route replace -- 替换已有的路由
　　缩写：add、a；change、chg；replace、repl
　　示例1: 设置到网络10.0.0/24的路由经过网关193.233.7.65
　　# ip route add 10.0.0/24 via 193.233.7.65
　　示例2: 修改到网络10.0.0/24的直接路由，使其经过设备dummy
　　# ip route chg 10.0.0/24 dev dummy
　　示例3: 实现链路负载平衡.加入缺省多路径路由，让ppp0和ppp1分担负载(注意：scope值并非必需，它只不过是告诉内核，
　　这个路由要经过网关而不是直连的。实际上，如果你知道远程端点的地址，使用via参数来设置就更好了)。
　　# ip route add default scope global nexthop dev ppp0 nexthop dev ppp1
　　# ip route replace default scope global nexthop dev ppp0 nexthop dev ppp1
　　示例4: 设置NAT路由。在转发来自192.203.80.144的数据包之前，先进行网络地址转换，把这个地址转换为193.233.7.83
　　# ip route add nat 192.203.80.142 via 193.233.7.83
　　示例5: 实现数据包级负载平衡,允许把数据包随机从多个路由发出。weight 可以设置权重.
　　# ip route replace default equalize nexthop via 211.139.218.145 dev eth0 weight 1 nexthop via 211.139.218.145 dev eth1 weight 1
　　7.4.ip route delete-- 删除路由
　　缩写：delete、del、d
　　示例1:删除上一节命令加入的多路径路由
　　# ip route del default scope global nexthop dev ppp0 nexthop dev ppp1
　　7.5.ip route show -- 列出路由
　　缩写：show、list、sh、ls、l
　　示例1: 计算使用gated/bgp协议的路由个数
　　# ip route ls proto gated/bgp |wc
　　1413 9891 79010
　　示例2: 计算路由缓存里面的条数，由于被缓存路由的属性可能大于一行，以此需要使用-o选项
　　# ip -o route ls cloned |wc
　　159 2543 18707
　　示例3: 列出路由表TABLEID里面的路由。缺省设置是table main。TABLEID或者是一个真正的路由表ID或者是/etc/iproute2/rt_tables文件定义的字符串，
　　或者是以下的特殊值：
