title: 发布镜像到docker hub上
date: '2019-09-15 18:36:16'
updated: '2019-09-15 18:36:16'
tags: [Docker, Docker入门到熟练]
permalink: /articles/2019/09/15/1568543776189.html
---
镜像创建好后，很重要的一个操作就是共享和发布。可以将自己创建的镜像发布到docker hub上，也可以发布到自己的私有docker hub上。
要想发布镜像到dokcer hub上，首先要在dokcer hub上注册账户，并且在本机（准备提交镜像到docker hub的机器上）上进行注册。具体过程如下：
1、登录 https://hub.docker.com/ 网站注册一个用户，如 jeme。注册时需要提供邮箱进行验证。
2、在本机用docker login 向docker hub注册（登录），如：
xxx@ubuntu:~$ docker login
Username: jeme
Password:
Email: xxxxxxxx@sss.sss
WARNING: login credentials saved in /home/xxx/.docker/config.json
Login Succeeded
说明：验证通过后，就可以开始将本地创建的镜像发布到docker hub自己的账户下了。
可以通过 docker logout命令退出docker hub，退出后就没法发布镜像到docker hub，除非再次注册。
3、发布镜像
docker push 用户名/仓库名[:tag名]
这里的 用户名/仓库名[:tag名]  代表的镜像必须是本机存在的，tag名不写的话默认就是latest。 也就是说在创建镜像时的命名必须是规范的格式（加用户名）。
并且用户名就是自己在docker hub上注册的名称。如这里的jeme.
发布成功后，这时我们用docker search 就能搜到自己提的镜像。
