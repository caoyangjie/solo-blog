title: Dockerfile 指令 ENTRYPOINT介绍
date: '2019-09-15 18:36:35'
updated: '2019-09-15 18:36:35'
tags: [Docker入门到熟练, Docker]
permalink: /articles/2019/09/15/1568543795598.html
---
本文介绍Dockerfile的 ENTRYPOINT指令的含义。
先回顾下CMD指令的含义，CMD指令可以指定容器启动时要执行的命令，但它可以被docker run命令的参数覆盖掉。
ENTRYPOINT 指令和CMD类似，它也可用户指定容器启动时要执行的命令，但如果dockerfile中也有CMD指令，CMD中的参数会被附加到ENTRYPOINT 指令的后面。 如果这时docker run命令带了参数，这个参数会覆盖掉CMD指令的参数，并也会附加到ENTRYPOINT 指令的后面。
这样当容器启动后，会执行ENTRYPOINT 指令的参数部分。
可以看出，相对来说ENTRYPOINT指令优先级更高。
我们来看个例子，下面是Dockerfile的内容

#test
FROM ubuntu
MAINTAINER hello
RUN echo hello1 > test1.txt
RUN echo hello2 > /test2.txt
EXPOSE 80
ENTRYPOINT ["echo"]
CMD ["defaultvalue"]

假设通过该Dockerfile构建的镜像名为 myimage。
 
1、当运行 docker run myimage  输出的内容是 defaultvalue，可以看出CMD指令的参数得确是被添加到ENTRYPOINT指令的后面，然后被执行。

2、当运行docker run myimage hello world  输出的内容是 hello world ，可以看出docker run命令的参数得确是被添加到ENTRYPOINT指令的后面，然后被执行，这时CMD指令被覆盖了。
 
3、另外我们可以在docker run命令中通过 --entrypoint 覆盖dockerfile文件中的ENTRYPOINT设置，如：
docker run --entrypoint="echo" myimage good  结果输出good
 注意，不管是哪种方式，创建容器后，通过 dokcer ps查看容器信息时，COMMOND列会显示最终生效的启动命令。
