title: 《mybatis源码》阅读笔记
date: '2019-09-16 09:25:21'
updated: '2019-09-16 09:25:21'
tags: [Mybatis, 阅读笔记]
permalink: /articles/2019/09/16/1568597121523.html
---
标题 | 内容
---|---
本文作者 | chaosj
阅读时间 | 2019年1月15日

## 总结阅读
```
mybatis源码解析主要内容分成两大块:{

    配置文件的解析过程
    
    Mapper接口的获取执行过程
    
}

```

### 1.配置文件的解析过程
```
SqlSessionFactoryBuilder().build(reader){
    构建DefaultSqlSessionFactory对象{
        执行XMLConfigBuilder.parse函数{
            执行mybatis-config.xml配置的解析过程{(当前类： XMLConfigBuilder)
                1.解析properties{
                    1.获取 resource 资源配置
                    2.获取 url 网络资源配置
                    3.设置 properties到 XPathParse,Configuration中
                }
                2.解析settings{
                    1.获取 settings 中的配置信息
                    2.获取 vsImpl 值，设置VFS类实例类
                }
                3.解析typeAliases{
                    1.检查typeAliases下是否设置包名,有设置则扫描整包中的类对象
                    2.设置 alias,type 中的值到 别名注册器中 typeAliasRegistry对象
                }
                4.解析plugins{
                    1.获取所有的 interceptor对象
                    2.获取 interceptor 实例对象
                    3.添加 interceptor 实例对象到 拦截器链路
                }
                5.解析objectFactory{
                    1.获取 objectFactory 实现类字符串
                    2.获取 objectFactory 下设置的 properties属性
                    3.初始化 objectFactory 对象下的 properteis属性
                }
                6.解析objectWrapperFactory{
                    1.获取 objectWrapperFactory 实现类字符串
                    2.获取 objectWraaperFactory 实例对象
                    3.将 objectWraaperFactory 设置进 Configuration 对象中
                }
                7.解析reflectorFactory{
                    1.获取 reflectorFactory 实现类字符串
                    2.获取 reflectorFactory 实例对象
                    3.设置 reflectorFactory 进 Configuration 对象中
                }
                8.初始化settings属性{
                    将第2步获取的settings属性设置进入Configuration对象中
                }
                9.解析environments{
                    1.获取 environments 属性XNode对象
                    2.从environments的 default 属性节点上获取默认环境配置
                    3.遍历子节点 environment{
                        1.判断是否与 default 获取的默认环境匹配{
                            // 匹配
                            1.根据 transactionManager 节点内容获取 TransactionFactory对象
                            2.根据 dataSource 获取 DataSourceFactory对象
                            3.根据 dataSourceFactory对象获取 DataSource对象
                            4.将构建成功的 environment对象存入 Configuration 对象中
                        }
                    }
                }
                10.解析databaseIdProvider{
                    1.获取 databaseIdProvider 的属性节点 type
                    2.构建一个 databaseIdProvider 对象
                    3.初始化 databaseIdProvider对象中的属性
                }
                11.解析typeHandlers{
                    1.获取 typeHandlers 下的所有子节点
                    2.遍历所有 typeHandler
                    3.判断子节点是否存在 package 节点名称{
                        // 存在 package 节点名称
                        1.获取 name 属性节点的值
                        2.扫描 name 指定的包路径下的所有实现了 TypeHandler接口的类
                        3.将所有的类 注入到 typeHandlerRegistry 注册器中
                    }
                    4. 获取 javaType,jdbcType,handler 等属性节点值
                    5.将获取的相关对象注入到 typeHandlerRegistry 注册器中
                }
                12.解析mappers配置{
                    1. 整个过程非常复杂,另起一个章节来进行拆分讲解
                }
                返回 Configuration 对象
            }
        }
    }
}
2.解析 Mappers 配置节点{
    
}
```
### 2.Mapper接口的获取执行过程
```
1.获取sqlsession对象{
    1. 执行 DefaultSqlSessionFactory 的 openSession 函数{
        1.调用 openSessionFromDataSource 函数{
            1.从 Configuration 中获取 Environment 对象
            2.判断 environment 对象中是否配置有 TransactionFactory对象{
                有：    返回 environment 中配置的 TransactionFactory 对象
                没有：  返回 ManagedTransactionFactory 对象
            }
            3.跟进 TransactionFactory 获取 Transaction 对象
            4.构建一个 Executor 执行器对象{
                1.如果是批量执行器： 创建 BatchExecutor 对象
                2.如果是可重用执行器： 创建 ReuseExecutor 对象
                3.否则： 创建一个 SimpleExecutor 对象
            }
            5.判断是否开启一级缓存{
                是： 包装 第4步构建的 Executor 执行,添加为 CachingExecutor 执行器
                否： 不动
            }
            6.添加拦截器链路中的方法 给 Executor 添加包装外壳
            7.返回 Executor 对象
        }
        2.返回 DefaultSqlSession 对象
    }
}
2.获取Mapper对象{
    1.调用 DefaultSqlSession 的 getMapper 函数{
        1.调用 Configuration 的 getMapper 函数{
            1.调用 mappRegistry 的 getMapper 函数{
                1. 判断是否已经缓存 type 类的 MapperProxyFactory 对象{
                    不存在： 抛出异常 BindingException
                }
                2.创建 sqlSession 的代理对象{
                    1.创建 MapperProxy 对象
                    2.创建 MapperProxy 对象的动态代理对象
                }
                3.返回 MapperProxy 的动态代理对象
            }
        }
    }
    2.调用 Mapper 的某个方法{
        1.执行 MapperProxy 的 invoke 函数{
            1.如果是 Object 父类中定义的 方法，直接调用
            2.如果是 Default 关键字定义的函数，通过JDK8 的 default 反射方式调用
            3.如果这个 method 方法没有执行过：创建,否则直接使用 MapperMethod 缓存对象
            4.执行 MapperMethod 对象的 execute 函数{
                ①.判断 SqlCommand 对象的 SqlCommandType类型{
                    case insert:{
                        1.获取 2调用Mapper 的某个方法的 方法参数
                        2.执行 DefaultSqlSession 的 insert 函数
                    }
                    case update:{
                        1.获取 2调用Mapper 的某个方法的 方法参数
                        2.执行 DefaultSqlSession 的 update 函数
                    }
                    case delete:{
                        1.获取 2调用Mapper 的某个方法的 方法参数
                        2.执行 DefaultSqlSession 的 delete 函数
                    }
                    case select:{
                        1.判断 method 函数的返回参数,以及是否存在 ResultHandler 进行调用
                        2.执行 DefaultSqlSession 中的 select 相关方法
                    }
                    跳至 ②
                }
                ②.执行 DefaultSqlSession 中的具体方法{
                    1.根据 statement 名称获取 MappedStatement 对象{
                        1. insert/delete/update{
                            1.执行包装的 Executor 执行器中的 update 方法 跳至 ③
                        }
                        2. select{
                            1.执行包装的 Executor 执行器中的 select 方法 跳至 ③
                        }
                    }
                }
                ③.执行 BaseExecutor 执行器中的方法{
                    1.update{
                        1.清空本地一级缓存
                        2.执行 doUpdate 方法{
                            case BatchExecutor:{
                                1.构建 StatementHandler 对象{
                                    1.创建一个 RoutingStatementHandler 对象
                                    2.应用拦截器插件到 RoutingStatementHandler 对象，进行对象包装
                                    3.返回包装后的 RoutingStatementHandler 对象
                                }
                                2.获取执行SQL
                                3.判断是否为批次最后一条执行记录{
                                    是：{
                                        1.获取最后一条 statement 对象
                                        2.应用事务超时时间
                                        3.执行 SQL占位符 应用 跳至 ④
                                        4.应用 SQL 参数
                                    }
                                    否：{
                                        1.获取 connection 日志包装对象
                                        2.获取 statement 的 preparestatement 对象
                                        3.应用 SQL占位符 跳至 ④
                                        4.添加 BatchResult 对象到 batchResultList 对象中
                                    }
                                }
                            }
                            case ReuseExecutor:{
                                1.构建 StatementHandler 对象
                                2.构建 Statement 对象
                                3.执行 StatementHandler 的 update 方法，跳至 ④
                            }
                            case SimpleExecutor:{
                                1.构建 StatementHandler 对象
                                2.构建 Statement 对象
                                3.执行 StatementHandler 的 update 方法，跳至 ④
                                4.是否 Statement 资源
                            }
                        }
                    }
                    2.query{
                        1.判断是否必须强制清空缓存! 是：执行|否：不执行
                        2.判断缓存中是否存在查询结果! 是：获取|否：数据库查询
                        3.数据库查询{
                            1.本地缓存添加当前查询的占位符
                            2.执行真实的查询 doQuery{
                                case BatchExecutor:{
                                    1.刷入批量处理语句
                                    2.同 ③.1.2.1
                                    3.构建 包装了日志记录器的 connection 对象
                                    4.获取 statement 的 preparestatement 对象
                                    5.应用 SQL占位符 跳至 ④
                                    6.执行 statemantHandler的 query 方法，跳至 ④
                                }
                                case ReuseExecutor:{
                                    1.同③.1.2.1
                                    2.获取 statement 的 preparestatement 对象
                                    3.执行 statemantHandler的 query 方法，跳至 ④
                                }
                                case SimpleExecutor:{
                                    1.同③.1.2.1
                                    2.获取 statement 的 preparestatement 对象
                                    3.执行 statemantHandler的 query 方法，跳至 ④
                                    4.回收 statement 资源
                                }
                            }
                            3.添加真实的返回结果到 本地一级缓存
                            4.返回结果
                        }
                        4.遍历执行延迟加载列表，进行延迟加载数据的加载请求
                        5.返回查询结果
                    }
                }
                ④执行 statementHandler 实现类的方法{
                    1.query:{
                        case PreparedStatementHandler{
                            1.执行 statement 的 execute 方法
                            2.通过 resultSetHandler 的 handlerResultSets 函数 处理结果，跳至 ⑤
                        }
                        case SimpleStatementHandler{
                            1.获取需要执行的sql
                            2.通过 statement 执行 sql
                            3.通过 resultSetHandler 的 handlerResultSets 函数 处理结果，跳至 ⑤
                        }
                    }
                    2.update:{
                        case PreparedStatementHandler{
                            1.执行 statement 的 execute 方法
                            2.获取 bindSql 的参数对象
                            3.执行 keyGenerator 后置处理逻辑
                        }
                        case SimpleStatementHandler{
                            1.获取 sql 执行语句
                            2.获取 bindSql 的参数对象
                            3.获取 keyGenerator 对象{
                                1.Jdbc3KeyGenerator{
                                    1.执行 statement 的 execute 方法
                                    2.获取更新数量
                                    3.执行主键字段值的回设
                                }
                                2.SelectKeyGenerator{
                                    1.执行 statement 的 execute 方法
                                    2.执行 keyGenerator 的后置处理逻辑
                                }
                                3.NoKeyGenerator{
                                    1.执行 statement 的 execute 方法
                                    2.回设更新成功数量
                                }
                            }
                        }
                    }
                    3.prepare:{
                        1.构建 statement 对象
                        2.设置 statement 执行超时时间
                        3.设置 fetchSize 数目
                        4.返回 statement 对象{
                            异常：关闭 statement 对象，外抛 SQLExecption Or ExecutorExecption 异常
                        }
                    }
                    4.parameterize:{
                        case PreparedStatementHandler{
                            执行 DefaultParameterHandler 的 setParameters 函数，跳至 ⑥
                        }
                        case SimpleStatementHandler{
                            //空实现
                        }
                    }
                }
                ⑤执行包装的 DefaultResultSetHandler 类实例的 handleResultSets 函数{
                    1.获取首个 ResultSet 对象，封装成 ResultSetWrapper 对象
                    2.获取 ResultMap 列表,不考虑存储过程的情况下：只会有一个 ResultMap 对象
                    3.校验 ResultSetWraaper 对象，如果没有找到 ResultMap 映射则外抛异常 ExecutorException
                    4.执行 handleResultSet 函数{
                        1.判断是否有自定义的 ResultHandler 对象{
                            有：{
                                执行 handleRowValues 方法{
                                    1.判断是否有嵌套映射情况{
                                        1.校验不要使用 RowBounds对象
                                        2.校验不要使用自定义 ResultHandler
                                        3.执行 handleRowValuesForNestedResultMap 处理嵌套映射逻辑{
                                            
                                        }
                                    }else{
                                        执行 handleRowValuesForSimpleResultMap 处理简单映射逻辑{
                                            1.构建 DefaultResultContext 对象
                                            2.调用 ResultSetWrapper 获取 ResultSet 对象
                                            3.跳到指定的 ResultSet 对象
                                            4.判断 是否继续处理 ResultSet && 是否已经关闭 && 是否还有下一条{
                                                1.获取 鉴别器 discriminatedResultMap 对象
                                                2.调用 getRowValue 方法{
                                                    
                                                }
                                                3.将 映射创建的结果对象添加到 ResultHandler 的 resultList 中保持
                                            }
                                        }
                                    }
                                }
                            }
                            没有：{
                                1.创建 DefaultResultHandler 对象
                                2.执行 handleRowValues 方法{
                                    同： ⑤.4.1.有 逻辑
                                }
                                3.将 defaultResultHandler 的结果的回设进 multipleResults 对象中
                            }
                        }
                        2.关闭 ResultSet 对象
                    }
                    5.获取下一个 ResultSet 对象，并封装成 ResultSetWrapper 对象
                    6.清理嵌套的缓存对象
                }
                ⑥执行 DefaultParameterHandler 的 setParameters 函数{
                    1.获取 ParameterMapping 数组
                    2.遍历 parameterMapping 数组{
                        通过 TypeHandler 处理结果
                    }
                }
            }
        }
    }
}
```
