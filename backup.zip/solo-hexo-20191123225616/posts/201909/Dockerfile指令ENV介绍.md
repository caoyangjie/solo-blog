title: Dockerfile 指令 ENV介绍
date: '2019-09-15 18:37:25'
updated: '2019-09-15 18:37:25'
tags: [Docker入门到熟练, Docker]
permalink: /articles/2019/09/15/1568543845362.html
---
ENV指令用来在镜像构建过程中设置环境变量。我们来看一个Dockerfile的例子：

按 Ctrl+C 复制代码

按 Ctrl+C 复制代码

假设用上面的dockerfile构建了一个叫myimage的镜像。

运行  docker run -i -t myimage /bin/bash

我们发现新建的容器中有了 /mydir目录，并有了/mydir/test.txt文件，文件内容为 hello world

1、通过ENV定义的环境变量，可以被后面的所有指令中使用，如上面的例子

2、但是不能被CMD指令使用，也不能被docker run 的命令参数引用。这个需要注意

3、通过ENV定义的环境变量，会永久的保存到该镜像创建的任何容器中。这样除了不能在上面说的启动命令中使用外，可以在后续容器的操作中使用。

4、可以在docker run 命令中通过 -e标记来传递环境变量，这样容器运行时就可以使用该变量。如：

docker run -i -t -e "TEST=hello" ubuntu /bin/bash
