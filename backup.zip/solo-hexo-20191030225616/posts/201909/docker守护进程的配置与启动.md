title: docker守护进程的配置与启动
date: '2019-09-15 19:56:22'
updated: '2019-09-15 19:56:22'
tags: [Docker入门到熟练, Docker]
permalink: /articles/2019/09/15/1568548582591.html
---
安装好docker后，需要启动docker守护进程。有多种启动方式。
一、服务的方式
因为docker守护进程被安装成服务。所以，可以通过服务的方式启停docker守护进程，包括查看状态。
sudo start docker  //启动
sudo stop docker  //停止
sudo status docker  //查看状态
 
二、利用docker daemon命令
sudo docker daemon
利用sudo ps -A 可以获取守护进程的进程号
 
三、让远程api可以访问docker守护进程
sudo docker daemon -H tcp://0.0.0.0:2375
这需要每次都带参数，而且无法通过服务的方式启动。
可以通过在配置文件配置，来让服务启动也可以让远程访问生效。
对于ubuntu操作系统，修改/etc/default/docker文件中的DOCKER_OPTS设置，如下：
# Use DOCKER_OPTS to modify the daemon startup options.
#DOCKER_OPTS="--dns 8.8.8.8 --dns 8.8.4.4"
DOCKER_OPTS="-H=unix:///var/run/docker.sock -H=0.0.0.0:2375"
这样通过 sudo start docker启动docker后，就可以远程访问了，如：
http://192.168.142.138:2375/info   //相当于在本地 docker info访问
http://192.168.142.138:2375/containers/json  //返回活动的容器
http://192.168.142.138:2375/containers/json？all=1 返回所有容器
除了利用web访问外，还可利用docker命令远程访问，如果别的机器上也装了docker，
访问方式如： docker -H  192.168.142.138:2375 info
注意：可以采用 sudo docker daemon 方式启动守护进程，然后进行本地的docker命令操作，可以铜鼓日志查看不同命令对应的url
 在linux下，可以通过curl工具访问url，因为返回的是json串，非格式化的。可以结合python命令，转为格式化的json，让看起来比较清楚。如：
curl http://192.168.142.138:2375/images/json | python -mjson.tool
