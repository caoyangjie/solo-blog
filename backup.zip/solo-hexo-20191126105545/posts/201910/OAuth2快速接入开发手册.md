title: OAuth2快速接入开发手册
date: '2019-10-28 11:27:19'
updated: '2019-10-28 11:28:16'
tags: [SpringCloud, OAuth2]
permalink: /articles/2019/10/28/1572233239722.html
---
![](https://img.hacpai.com/bing/20171221.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# OAuth2快速接入开发手册

## 简介
OAuth2是一个关于授权的开放标准，核心思路是通过各类认证手段（具体什么手段OAuth2不关心）认证用户身份，并颁发token（令牌），使得第三方应用可以使用该令牌在限定时间、限定范围访问指定资源。
主要涉及的RFC规范有RFC6749（整体授权框架）,RFC6750（令牌使用）,RFC6819（威胁模型）这几个，一般我们需要了解的就是RFC6749。
获取令牌的方式主要有四种，
分别是
- 授权码模式
- 简单模式
- <font color="yellow">密码模式</font>
- 客户端模式

我们这里从客户端已经通过某种方式获取到了access_token 到 应用系统如何对接接入进行详细解释说明
我们这里主要讲解的是 4种授权模式中的
- <font color="yellow">密码模式</font>

想了解具体的oauth2授权步骤可以移步<font color="red">阮一峰老师</font>的 [理解OAuth 2.0](http://www.ruanyifeng.com/blog/2014/05/oauth_2_0.html)，里面有非常详细的说明。

## 快速入门

### OAuth2的重要概念
|           概念                |                             介绍                                                           |
| ----------------------------- | ------------------------------------------------------------------------------------------ |
| resource owner                | 资源所有者,即决定此资源开发与否的角色                                                      |
| user agent                    | 一般来说都是讲的浏览器                                                                     |
| client                        | 第三方应用,对应Fast框架来说,公司内部所有的应用方都可以认为是client                         |
| authorization server          | 认证服务器,对应Fast框架来说,就是 eureka 上的实例 <font color="red">auth</font>服务         |
| resource server               | 资源服务器,对应Fast框架来说,就是 eureka 上所有需要访问时获取用户信息的微服务               |

### SpringCloud Security OAuth2的授权流程
- 用户登陆脸盆网，脸盆网试图访问facebook上的好友列表
- 脸盆网发现该资源是facebook的受保护资源，于是返回302将用户重定向至facebook登陆页面
- 用户完成认证后，facebook提示用户是否将好友列表资源授权给脸盆网使用（如果本来就是已登陆facebook状态则直接显示是否授权的页面）
- 用户确认后，脸盆网通过授权码模式获取了facebook颁发的access_token
- 脸盆网携带该token访问facebook的获取用户接口 http://localhost:6789/oauth/token
- 脸盆网的spring security安全框架根据返回的用户信息构造出了principal对象并保存在session中
- 脸盆网再次携带该token访问好友列表，facebook根据该token对应的用户返回该用户的好友列表信息
- 该用户后续在脸盆网发起的访问facebook上的资源，只要在token有效期及权限范围内均可以正常获取（比如想访问一下保存在facebook里的相册）

## 接入须知
本文档的核心内容是 Fast框架是如何搭建的基于<font color="red">SpringCloud Security OAuth2</font> 的认证系统
如果您只关心应用如何快速接入,可以跳过：
* <font color="green">开发用户服务</font>
* <font color="green">开发认证服务</font>
* <font color="green">开发网关服务</font>

以上三个章节的内容,直接阅读：
* <font color="red">开发资源服务</font>

即可了解到在Fast框架下如何进行 资源服务的接入

### <font color="green">开发用户服务</font>
#### application.yml配置
```yml
spring:
  application:
    name: user-service

server:
  port: 6666

eureka:
  instance:
    prefer-ip-address: true
    instance-id: ${spring.cloud.client.ip-address}:${server.port}
  client:
    service-url:
      defaultZone: http://eureka部署地址:部署端口/eureka/
```
#### UserLoginController 开发
```
/**
 * @Description:
 * @author: caoyangjie
 * @date: 2019年10月2019/10/25日 15:32
 * @Copyright: © 赢时胜
 */
@RestController
@RequestMapping("/api")
public class UserLoginController {

    @Autowired
    private IUserService userService;
    /**
     * 根据用户名获取用户信息
     * @return true/false
     */
    @PostMapping("/findUserByName")
    public YssResponse<UserVO> removeToken(@RequestParam("username") String userName) {
        return new YssResponse<UserVO>(userService.findUserByName(userName));
    }
}
```
#### IUserService 开发
```
/**
 * @Description:
 * @author: caoyangjie
 * @date: 2019年10月2019/10/25日 15:37
 * @Copyright: © 赢时胜
 */
public interface IUserService<T extends BasePojo, ID extends Serializable> extends IBaseService<T,ID> {
    UserVO findUserByName(String name);
}
```
#### UserServiceImpl 开发
```
/**
 * @Description:
 * @author: caoyangjie
 * @date: 2019年10月2019/10/25日 15:39
 * @Copyright: © 赢时胜
 */
@Primary
@YssOldService(cSharpName = "IUserService", custom = "", menuId = "userService", newService = false, interfaceClass = IUserService.class)
public class UserServiceImpl extends AbstractBaseService<User, String> implements IUserService<User, String> {
    @Override
    public UserVO findUserByName(String name) {
        //TODO 这里自行实现
        return null;
    }
}
```

好了,开发的SpringBoot的用户微服务就完成了,启动即可

### <font color="green">开发认证服务</font>
<font color="yellow">认证服务器相关概念介绍</font>

|           概念                                      |                             介绍                                                           |
| --------------------------------------------------- | ------------------------------------------------------------------------------------------ |
| WebSecurityConfigurerAdapter                        | WEB安全策略配置适配器                                                                      |
| AuthorizationServerConfigurerAdapter                | 认证服务配置适配器                                                                         |
| TokenStore                                          | 认证后用户相关信息存储引擎,主要有5中：Redis/Jwt/Jdbc/InMemory/Jwk                          |
| UserDetailsService                                  | SpringCloud Security OAuth2 要求的查询用户信息接口                                         |
| UserDetails                                         | UserDetailsService 接口 要求返回的 用户详情接口                                            |
| JwtAccessTokenConverter                             | Jwt访问Token转换器                                                                         |
| TokenEnhancerChain                                  | 令牌增强链                                                                                 |

#### WebSecurityConfigurerAdapter配置
请注意此处需要使用
* <font color="red"> @EnableWebSecurity </font>
* <font color="red">@Order(2)</font>
```
@Configuration
@EnableWebSecurity
@Order(2)
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {
    @Autowired
    private UserDetailsService userDetailService;

    @Bean
    public PasswordEncoder passwordEncoder() {
        //TODO 这里需要使用加密算法
//        return new BCryptPasswordEncoder();
        return new NoEncryptPasswordEncoder();
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.requestMatchers().antMatchers("/oauth/**")
                .and()
                .authorizeRequests()
                .antMatchers("/oauth/**").authenticated()
                .and()
                .csrf().disable();
    }

    @Override
    public void configure(WebSecurity web) throws Exception {
        web.ignoring().antMatchers("/favor.ioc");
    }

    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth.userDetailsService(userDetailService).passwordEncoder(passwordEncoder());
    }

    /**
     * 不定义没有password grant_type,密码模式需要AuthenticationManager支持
     *
     * @return
     * @throws Exception
     */
    @Override
    @Bean
    public AuthenticationManager authenticationManagerBean() throws Exception {
        return super.authenticationManagerBean();
    }
}
```
#### AuthorizationServerConfigurerAdapter配置
```
/**
 * @Description: 注解开启在方法上的保护功能
 * @author: caoyangjie
 * @date: 2019年10月2019/10/22日 10:45
 * @Copyright: © 赢时胜
 */
@Configuration
@EnableAuthorizationServer
@Order(value = Integer.MIN_VALUE)
@AutoConfigureBefore(value = {RedisAutoConfiguration.class,DataSourceAutoConfiguration.class})
public class YssAuthorizationServerConfig extends AuthorizationServerConfigurerAdapter {

    /**
     * 必须要有这个 才支持 password 授权模式
     */
    @Autowired
    private AuthenticationManager authenticationManager;

    /**
     * 这个是实现 框架要求的 UserDetailsService 接口的服务
     */
    @Autowired
    private UserDetailsService userDetailsService;

    /**
     * 注入 SpringBoot 框架提供的 Redis 连接工厂
     */
    @Autowired
    private RedisConnectionFactory redisConnectionFactory;

    /**
     * WEB返回异常包装器
     */
    @Autowired
    private WebResponseExceptionTranslator customWebResponseExceptionTranslator;

    /**
     * 数据库连接对象
     */
    @Autowired
    private DataSource dataSource;

    @Override
    public void configure(ClientDetailsServiceConfigurer clients) throws Exception {
        //配置 客户端 信息获取方式
        clients.withClientDetails(clientDetails());
    }

    @Override
    public void configure(AuthorizationServerEndpointsConfigurer endpoints) {
        //  授权服务切面配置 增强
        endpoints
                .tokenServices(defaultTokenServices())
                .tokenStore(redisTokenStore())
                .authenticationManager(authenticationManager)
                .reuseRefreshTokens(false)
                .userDetailsService(userDetailsService)
                .exceptionTranslator(customWebResponseExceptionTranslator);
    }

    @Override
    public void configure(AuthorizationServerSecurityConfigurer security) throws Exception {
        // 授权服务安全策略配置
        security
                .allowFormAuthenticationForClients()
                .tokenKeyAccess("isAuthenticated()")
                .checkTokenAccess("permitAll()");
    }

    /**
     * 返回一个 Spring 管理的 JwtAccessTokenConverter, 进行 签名增强, 也可以考虑在这里面进行 jwt的加解密相关配置
     * @return
     */
    @Bean
    public JwtAccessTokenConverter jwtAccessTokenConverter() {
        YssJwtAccessTokenConverter jwtAccessTokenConverter = new YssJwtAccessTokenConverter();
        jwtAccessTokenConverter.setSigningKey(AuthConstants.SIGN_KEY);
        return jwtAccessTokenConverter;
    }

    /**
     * tokenstore 定制化处理
     *
     * @return TokenStore
     * 1. 如果使用的 redis-cluster 模式请使用 ddtkRedisTokenStore
     * ddtkRedisTokenStore tokenStore = new ddtkRedisTokenStore();
     * tokenStore.setRedisTemplate(redisTemplate);
     */
    public TokenStore redisTokenStore() {
        RedisTokenStore tokenStore = new RedisTokenStore(redisConnectionFactory);
        tokenStore.setPrefix(AuthConstants.YSS_PREFIX);
        return tokenStore;
    }

    /**
     * jwt 生成token 定制化处理
     * @return TokenEnhancer
     */
    @Bean
    public TokenEnhancer tokenEnhancer() {
        return (accessToken, authentication) -> {
            final Map<String, Object> additionalInfo = new HashMap<>(2);
            additionalInfo.put(AuthConstants.LICENSE, AuthConstants.YSS_LICENSE);
            UserDetailsImpl user = (UserDetailsImpl) authentication.getUserAuthentication().getPrincipal();
            if (user != null) {
                additionalInfo.put("userId", user.getUserId());
            }
            additionalInfo.put("code", 0);
            ((DefaultOAuth2AccessToken) accessToken).setAdditionalInformation(additionalInfo);
            return accessToken;
        };
    }

    /**
     * 配置 可以接受认证的 client 端点配置信息的服务， 这里使用的是 jdbc 保存数据库中
     * @return
     */
    public ClientDetailsService clientDetails() {
        return new JdbcClientDetailsService(dataSource);
    }

    /**
     * <p>注意，自定义TokenServices的时候，需要设置@Primary，否则报错，</p>
     * @return
     */
    public DefaultTokenServices defaultTokenServices(){
        TokenEnhancerChain tokenEnhancerChain = new TokenEnhancerChain();
        tokenEnhancerChain.setTokenEnhancers(Arrays.asList(tokenEnhancer(), jwtAccessTokenConverter()));
        DefaultTokenServices tokenServices = new DefaultTokenServices();
        tokenServices.setTokenStore(redisTokenStore());
        tokenServices.setTokenEnhancer(tokenEnhancerChain);
        tokenServices.setSupportRefreshToken(true);
        tokenServices.setClientDetailsService(clientDetails());
        //token有效期自定义设置，默认12小时
        tokenServices.setAccessTokenValiditySeconds(60*60*12);
        //默认30天，这里修改
        tokenServices.setRefreshTokenValiditySeconds(60 * 60 * 24 * 7);
        return tokenServices;
    }
}
```
#### TokenStore配置
```
此配置就基本与 RedisTokenStore 配置一致,如果需要自定义进行一些增强操作,可以将 框架提供的 RedisTokenStore 拷贝后进行改造
```
#### UserDetailsService配置
```
/**
 * @Description:
 * @author: caoyangjie
 * @date: 2019年10月2019/10/22日 10:45
 * @Copyright: © 赢时胜
 */
@Service("userDetailServiceImpl")
public class UserDetailServiceImpl implements UserDetailsService {

    @Autowired
    private ILoginServiceClient userService;

    @Override
    public UserDetailsImpl loadUserByUsername(String username) throws AuthenticationException {
        YssResponse<UserVO> response = userService.findUserByName(username);
        if (!response.isSuccess()) {
            throw new AuthenticationServiceException(response.getMsg());
        }
        UserVO user = response.getData();
        if( user==null ){
            throw new UsernameNotFoundException(SystemFacade.converter(new YssCoreException("Auth000007")));
        }
        if (AuthConstants.STATUS_LOCK.equals(user.getDelFlag())){
            throw new LockedException(SystemFacade.converter(new YssCoreException("Auth000006")));
        }
        return new UserDetailsImpl(user);
    }
}
```
#### UserDetails配置
```
/**
 * 需要我们自定义一个实体类去实现这些接口
 */
public interface UserDetails extends Serializable {
	Collection<? extends GrantedAuthority> getAuthorities();
	String getPassword();
	String getUsername();
	boolean isAccountNonExpired();
	boolean isAccountNonLocked();
	boolean isCredentialsNonExpired();
	boolean isEnabled();
}
```
#### TokenEnhancerChain 配置
```
    /**
     * 返回一个 Spring 管理的 JwtAccessTokenConverter, 进行 签名增强, 也可以考虑在这里面进行 jwt的加解密相关配置
     * @return
     */
    @Bean
    public JwtAccessTokenConverter jwtAccessTokenConverter() {
        YssJwtAccessTokenConverter jwtAccessTokenConverter = new YssJwtAccessTokenConverter();
        jwtAccessTokenConverter.setSigningKey(AuthConstants.SIGN_KEY);
        return jwtAccessTokenConverter;
    }


    /**
     * jwt 生成token 定制化处理
     * @return TokenEnhancer
     */
    @Bean
    public TokenEnhancer tokenEnhancer() {
        return (accessToken, authentication) -> {
            final Map<String, Object> additionalInfo = new HashMap<>(2);
            additionalInfo.put(AuthConstants.LICENSE, AuthConstants.YSS_LICENSE);
            UserDetailsImpl user = (UserDetailsImpl) authentication.getUserAuthentication().getPrincipal();
            if (user != null) {
                additionalInfo.put("userId", user.getUserId());
            }
            additionalInfo.put("code", 0);
            ((DefaultOAuth2AccessToken) accessToken).setAdditionalInformation(additionalInfo);
            return accessToken;
        };
    }

    /**
     * <p>注意，自定义TokenServices的时候，需要设置@Primary，否则报错，</p>
     * @return
     */
    public DefaultTokenServices defaultTokenServices(){
        TokenEnhancerChain tokenEnhancerChain = new TokenEnhancerChain();
        tokenEnhancerChain.setTokenEnhancers(Arrays.asList(tokenEnhancer(), jwtAccessTokenConverter()));
        DefaultTokenServices tokenServices = new DefaultTokenServices();
        tokenServices.setTokenStore(redisTokenStore());
        tokenServices.setTokenEnhancer(tokenEnhancerChain);
        tokenServices.setSupportRefreshToken(true);
        tokenServices.setClientDetailsService(clientDetails());
        //token有效期自定义设置，默认12小时
        tokenServices.setAccessTokenValiditySeconds(60*60*12);
        //默认30天，这里修改
        tokenServices.setRefreshTokenValiditySeconds(60 * 60 * 24 * 7);
        return tokenServices;
    }
```
做完上面这些步骤基本就已经完成了 <font color="red">认证服务</font>的开发任务
### <font color="green">开发网关服务</font>
#### 配置Zuul网关
**<font color="red">@EnableOAuth2Sso</font>注解必须开启**
```
@SpringBootApplication
@EnableDiscoveryClient
@EnableZuulProxy
@EnableOAuth2Sso
public class ZuulApplication {
    public static void main(String[] args) {
        SpringApplication.run(ZuulApplication.class, args);
    }
}
```
**<font color="red">application.yml</font>配置**
```
server:
  port: 1202

spring:
  application:
    name: eshop-gateway

#--------------------eureka---------------------
eureka:
  instance:
    prefer-ip-address: true
    instance-id: ${spring.cloud.client.ip-address}:${server.port}
  client:
    service-url:
      defaultZone: http://localhost:1111/eureka/

#--------------------Zuul-----------------------
zuul:
  routes:
    auth:
      path: /auth/**
      serviceId: auth-core
      sensitiveHeaders: "*"
  retryable: false
  ignored-services: "*"
  ribbon:
    eager-load:
      enabled: true
  host:
    connect-timeout-millis: 3000
    socket-timeout-millis: 3000
  add-proxy-headers: true


#---------------------OAuth2---------------------
security:
  oauth2:
    client:
      access-token-uri: http://localhost:${server.port}/auth/oauth/token
      user-authorization-uri: http://localhost:${server.port}/auth/oauth/authorize
      # 此值需要在 数据库中配置
      client-id: web
    resource:
      user-info-uri:  http://localhost:${server.port}/auth/api/member
      prefer-token-info: false
```
完成以上步骤,就完成了整个快速集成 OAuth2 到 Zuul网关

### <font color="red">开发资源服务</font>
#### 开发资源服务
**<font color="red">添加资源配置文件</font>**
```
@Configuration
@EnableResourceServer
public class ResourceServerConfig extends ResourceServerConfigurerAdapter {

    @Override
    public void configure(HttpSecurity http) throws Exception {
        http
                .csrf().disable()
                .exceptionHandling()
                .authenticationEntryPoint((request, response, authException) -> response.sendError(HttpServletResponse.SC_UNAUTHORIZED))
                .and()
                .requestMatchers().antMatchers("/api/**")
                .and()
                .authorizeRequests()
                .antMatchers("/api/**").authenticated()
                .and()
                .httpBasic();
    }

    @Override
    public void configure(ResourceServerSecurityConfigurer resources) throws Exception {
        super.configure(resources);
    }
}
```
**<font color="red">application.yml</font>**
```
security:
  oauth2:
    resource:
      id: eshop-member
      user-info-uri: http://localhost:{server.port}/auth/api/member
      prefer-token-info: false
```
**<font color="red">controller</font>开发**
```
@RestController
@RequestMapping("/api")
public class MemberController {

    //在请求参数中添加参数 Principal 对象,即可获取用户信息
    @GetMapping("current")
    public Principal user(Principal principal) {
        return principal;
    }

    @GetMapping("query")
    // 设置拥有的权限
    @PreAuthorize("hasAnyAuthority('query')")
    public String query() {
        return "具有query权限";
    }
}
```
