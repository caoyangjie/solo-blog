title: MYSQL必须得知道的内核知识
date: '2019-09-17 10:25:07'
updated: '2019-09-17 10:44:27'
tags: [58沈剑, 架构技巧, 数据库拆分, Mysql内核]
permalink: /articles/2019/09/17/1568687107197.html
---
![](https://img.hacpai.com/bing/20180816.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)


# 58沈剑-架构师之路
## 数据库相关知识
### MYSQL相关知识
#### 关于Mysql内核,一定要知道的
- [InnerDb并发为何如此之高](https://mp.weixin.qq.com/s?__biz=MjM5ODYxMDA5OQ==&mid=2651961444&idx=1&sn=830a93eb74ca484cbcedb06e485f611e&chksm=bd2d0db88a5a84ae5865cd05f8c7899153d16ec7e7976f06033f4fbfbecc2fdee6e8b89bb17b&scene=21#wechat_redirect)
- [快照读,在RR和RC下的差异](https://mp.weixin.qq.com/s?__biz=MjM5ODYxMDA5OQ==&mid=2651961513&idx=1&sn=e955133cbd87c652d9bcbccad608190e&chksm=bd2d0d758a5a84632046e7c692064b415621ae329426adf77ae03e4a0cc55d662d6d4c543019&scene=21#wechat_redirect)
- [InnoDB插入自增列，是表锁吗？](https://mp.weixin.qq.com/s?__biz=MjM5ODYxMDA5OQ==&mid=2651961455&idx=1&sn=4c26a836cff889ff749a1756df010e0e&chksm=bd2d0db38a5a84a53db91e97c7be6295185abffa5d7d1e88fd6b8e1abb3716ee9748b88858e2&scene=21#wechat_redirect)
- [InnoDB并发插入，会不会互斥？](https://mp.weixin.qq.com/s?__biz=MjM5ODYxMDA5OQ==&mid=2651961461&idx=1&sn=b73293c71d8718256e162be6240797ef&chksm=bd2d0da98a5a84bfe23f0327694dbda2f96677aa91fcfc1c8a5b96c8a6701bccf2995725899a&scene=21#wechat_redirect)
- [InnoDB，select为何会阻塞insert？](https://mp.weixin.qq.com/s?__biz=MjM5ODYxMDA5OQ==&mid=2651961471&idx=1&sn=da257b4f77ac464d5119b915b409ba9c&chksm=bd2d0da38a5a84b5fc1417667fe123f2fbd2d7610b89ace8e97e3b9f28b794ad147c1290ceea&scene=21#wechat_redirect)
- [数据库索引，到底是什么做的？](https://mp.weixin.qq.com/s?__biz=MjM5ODYxMDA5OQ==&mid=2651961486&idx=1&sn=b319a87f87797d5d662ab4715666657f&chksm=bd2d0d528a5a84446fb88da7590e6d4e5ad06cfebb5cb57a83cf75056007ba29515c85b9a24c&scene=21#wechat_redirect)
- [MyISAM与InnoDB的索引差异究竟是啥？](https://mp.weixin.qq.com/s?__biz=MjM5ODYxMDA5OQ==&mid=2651961494&idx=1&sn=34f1874c1e36c2bc8ab9f74af6546ec5&chksm=bd2d0d4a8a5a845c566006efce0831e610604a43279aab03e0a6dde9422b63944e908fcc6c05&scene=21#wechat_redirect)
- [InnoDB如何巧妙实现，事务的4种隔离级别？](https://mp.weixin.qq.com/s?__biz=MjM5ODYxMDA5OQ==&mid=2651961498&idx=1&sn=058097f882ff9d32f5cdf7922644d083&chksm=bd2d0d468a5a845026b7d2c211330a6bc7e9ebdaa92f8060265f60ca0b166f8957cbf3b0182c&scene=21#wechat_redirect)
- [别废话，各种SQL到底加了什么锁？](https://mp.weixin.qq.com/s?__biz=MjM5ODYxMDA5OQ==&mid=2651961508&idx=1&sn=9f31a95e5b8ec16fa0edc7de6087d2a1&chksm=bd2d0d788a5a846e3bf16d300fb9723047bd109fd22682c39bdf7ed4e77b167e333460f6987c&scene=21#wechat_redirect)
- [超赞，InnoDB调试死锁的方法！](https://mp.weixin.qq.com/s?__biz=MjM5ODYxMDA5OQ==&mid=2651961535&idx=1&sn=b62e9d71836ac5cf2d3cedf69e1ef395&chksm=bd2d0d638a5a84750adfc39d7e177a63330d6bde0f56600764b2d79e0fb9d96ad69e26e19ff1&scene=21#wechat_redirect)
- [MySQL不为人知的主键与唯一索引](https://mp.weixin.qq.com/s?__biz=MjM5ODYxMDA5OQ==&mid=2651961550&idx=1&sn=8c6de40ae8ac8a52095071fe0ff0fe03&chksm=bd2d0d128a5a8404733b0d6835c38c8c89a292af6dfdcb77da6b73cc2a2122f0f2571bc32428&scene=21#wechat_redirect)
- [InnoDB的五项最佳实践，知其所以然](https://mp.weixin.qq.com/s?__biz=MjM5ODYxMDA5OQ==&mid=2651961428&idx=1&sn=31a9eb967941d888fbd4bb2112e9602b&chksm=bd2d0d888a5a849e7ebaa7756a8bc1b3d4e2f493f3a76383fc80f7e9ce7657e4ed2f6c01777d&scene=21#wechat_redirect)
- [MySQL5.6，InnoDB的一些新特性](https://mp.weixin.qq.com/s?__biz=MjM5ODYxMDA5OQ==&mid=2651961448&idx=1&sn=b1be68798cfcb4511d62853d51b1ad12&chksm=bd2d0db48a5a84a27d098e3387d60c277f635d4d5ea6c3e0ad70b94a2151a6cc62ae65ddc365&scene=21#wechat_redirect)
- [InnoDB的七种锁 ](https://mp.weixin.qq.com/s?__biz=MjM5ODYxMDA5OQ==&mid=2651961451&idx=1&sn=1bac366be5ad2dc721f79c9cb8e65e34&chksm=bd2d0db78a5a84a101e05a02e337fe91c3fd179132bced897156e1f34f0d0ba7e48dc89a1b95&scene=21#wechat_redirect)
